

import java.util.concurrent.TimeUnit;
import java.util.*;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;
import org.testng.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.*;

import static org.testng.Assert.*;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import static org.openqa.selenium.support.ui.ExpectedConditions.elementToBeClickable;

public class LevelsBeyond  {
	  public WebDriver driver;
	  public String baseUrl = "http://www.google.com";
	  
  @Test
  public void f()throws Exception {
	    try {
	    WebDriverWait wait = new WebDriverWait(driver, 30);
	  	driver.get(baseUrl);	
	  	
	  	// Verify we are starting on the Google home page.
		assertEquals(driver.getTitle(), "Google");
		
		// Do a Google search on "levels beyond reach engine"
		driver.findElement(By.id("lst-ib")).sendKeys("levels beyond reach engine");
		WebElement searchBtn = driver.findElement(By.name("btnK"));
		searchBtn.submit();
		
		//Retrieve all Google search results and click on first result
		List<WebElement> SearchResults = driver.findElements(By.tagName("h3"));
		SearchResults.get(0).click();
		
		//Verify correct page loaded
		assertEquals(driver.getTitle(), "Reach Engine by Levels Beyond | Video Content Management Platform");
		
		//Verify page content
		WebElement PageText = driver.findElement(By.xpath("//*[@id=\"post-11026\"]/div/div[1]/section/div[1]/div/div/h2"));
		assertEquals(PageText.getText(), "YOUR PLATFORM FOR INTELLIGENT CONTENT");
		wait.until(elementToBeClickable(By.linkText("Company")));
		Thread.sleep(2000);
		
		//Select Menu Company -> Team 
        Actions builder = new Actions(driver); 
        WebElement CompanyMenu = driver.findElement(By.linkText("Company"));
        builder.moveToElement(CompanyMenu ).build().perform();
        WebElement Teamsubmenu=  driver.findElement(By.xpath("//*[@id=\"menu-item-5116\"]/a")); //Find the Team submenu
        builder.moveToElement(Teamsubmenu).click().build().perform();
        
        //Verify Page header
        WebElement HeaderText = driver.findElement(By.xpath("//*[@id=\"post-100\"]/div/div[1]/section/div[1]/div/div/h1"));
        assertEquals(HeaderText.getText(), "OUR TEAM");
        
        //Verify CEO on Team page
        WebElement NameText = driver.findElement(By.xpath("//*[@id=\"post-100\"]/div/div[2]/div[1]/div[1]/div/div[2]/h4"));
        WebElement PositionText = driver.findElement(By.xpath("//*[@id=\"post-100\"]/div/div[2]/div[1]/div[1]/div/div[2]/p"));
        assertEquals(NameText.getText(), "Art Raymond");
        assertEquals(PositionText.getText(), "CEO");
        
        //Search on Art Raymond
        WebElement SearchBtn = driver.findElement(By.xpath("//*[@id=\"et_top_search\"]"));
        SearchBtn.click();
        driver.findElement(By.className("et-search-field")).sendKeys("Art Raymond"+ "\n");
        
        //Verify links for Art Raymond
		List<WebElement> CEOResults = driver.findElements(By.tagName("h2"));
		int linkcount = CEOResults.size(); 
		assertTrue(linkcount>=3);
        }catch (Exception e){
            System.out.println("error "+e);
        }
  }
  @BeforeTest
  public void beforeTest() {
	  	//Setup for Chrome browser
		System.setProperty("webdriver.chrome.driver", "C:\\Selenium\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
  }

  @AfterTest
  public void afterTest() {
	    driver.quit();
  }

}
